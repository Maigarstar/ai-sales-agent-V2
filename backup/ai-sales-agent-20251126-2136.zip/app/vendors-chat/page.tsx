"use client";

import { useEffect, useRef, useState, FormEvent } from "react";

type Role = "vendor" | "ai";

type LeadType = "Hot" | "Warm" | "Cold";

interface VendorMetadata {
  score?: number;
  leadType?: LeadType;
  businessCategory?: string;
  location?: string;
  clientBudget?: string;
  style?: string;
  marketingChannels?: string;
}

interface Message {
  id: string;
  role: Role;
  content: string;
  meta?: VendorMetadata;
}

function createId() {
  return Math.random().toString(36).slice(2);
}

const leadBadgeStyles: Record<LeadType, string> = {
  Hot: "bg-emerald-600 text-emerald-50",
  Warm: "bg-amber-500 text-amber-50",
  Cold: "bg-zinc-500 text-zinc-50",
};

export default function VendorChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: createId(),
      role: "ai",
      content:
        "Welcome to 5 Star Weddings, it is lovely to meet you. Tell me a little about your business, what you offer and where you are based, and I will guide you through whether our collection is the right fit for you.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // keep chat scrolled to latest message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isSending) return;

    const vendorMessage: Message = {
      id: createId(),
      role: "vendor",
      content: trimmed,
    };

    const nextMessages = [...messages, vendorMessage];

    setMessages(nextMessages);
    setInput("");
    setIsSending(true);

    const aiId = createId();

    // placeholder AI bubble while we wait
    setMessages((prev) => [
      ...prev,
      {
        id: aiId,
        role: "ai",
        content: "",
      },
    ]);

    // format messages for OpenAI
    const payloadMessages = nextMessages.map((m) => ({
      role: m.role === "vendor" ? "user" : "assistant" as const,
      content: m.content,
    }));

    try {
      const res = await fetch("/api/chat/vendors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: payloadMessages }),
      });

      if (!res.body) {
        setIsSending(false);
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();

      let fullText = "";

      // collect complete response first
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        fullText += decoder.decode(value, { stream: true });
      }

      // extract metadata block
      const metaMatch = fullText.match(
        /<metadata>\s*([\s\S]*?)\s*<\/metadata>/i
      );

      let visibleText = fullText;
      let meta: VendorMetadata | undefined;

      if (metaMatch) {
        visibleText = fullText.replace(metaMatch[0], "").trim();

        try {
          const raw = JSON.parse(metaMatch[1]);

          meta = {
            score: typeof raw.score === "number" ? raw.score : undefined,
            leadType: raw.lead_type as LeadType | undefined,
            businessCategory: raw.business_category ?? undefined,
            location: raw.location ?? undefined,
            clientBudget: raw.client_budget ?? undefined,
            style: raw.style ?? undefined,
            marketingChannels: raw.marketing_channels ?? undefined,
          };
        } catch (err) {
          console.error("Failed to parse vendor metadata", err);
        }
      }

      // update AI message with clean text and meta
      setMessages((prev) =>
        prev.map((m) =>
          m.id === aiId
            ? {
                ...m,
                content: visibleText,
                meta,
              }
            : m
        )
      );

      // fire and forget save to backend
      if (meta) {
        try {
          await fetch("/api/vendors-chat/save-lead", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              meta,
              lastVendorMessage: trimmed,
              transcript: [...nextMessages, { id: aiId, role: "ai", content: visibleText }],
            }),
          });
        } catch (err) {
          console.error("Failed to save lead", err);
        }
      }
    } catch (error) {
      console.error(error);
      setMessages((prev) =>
        prev.map((m) =>
          m.role === "ai" && m.content === ""
            ? {
                ...m,
                content:
                  "I am having a little difficulty responding at the moment. Please try again in a moment.",
              }
            : m
        )
      );
    } finally {
      setIsSending(false);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-3xl rounded-3xl bg-white shadow-2xl border border-zinc-200 overflow-hidden">
        {/* Header */}
        <div className="px-8 py-6 border-b border-zinc-100 bg-gradient-to-r from-zinc-50 to-zinc-100">
          <p className="text-xs tracking-[0.25em] uppercase text-zinc-500 mb-2">
            5 Star Weddings
          </p>
          <h1 className="text-2xl font-semibold text-zinc-900">
            Vendor Sales Agent
          </h1>
          <p className="mt-2 text-sm text-zinc-600 max-w-xl">
            Share a little about your brand, and I will guide you through
            whether our luxury collection is the right fit and what your next
            steps could be.
          </p>
        </div>

        {/* Chat area */}
        <div className="px-6 pt-6 pb-4">
          <div
            ref={scrollRef}
            className="h-96 md:h-[420px] rounded-2xl border border-zinc-100 bg-zinc-50/60 px-4 py-4 overflow-y-auto"
          >
            {messages.map((m) => {
              const isVendor = m.role === "vendor";
              const leadType = m.meta?.leadType;
              const score = m.meta?.score;

              return (
                <div
                  key={m.id}
                  className={`mb-4 flex ${
                    isVendor ? "justify-end" : "justify-start"
                  }`}
                >
                  <div className="flex items-start gap-3 max-w-[90%]">
                    {!isVendor && leadType && (
                      <div
                        className={`self-start text-[10px] px-3 py-1 rounded-full uppercase tracking-[0.18em] ${leadBadgeStyles[leadType]}`}
                      >
                        {leadType} lead
                        {typeof score === "number" ? ` ${score}/10` : ""}
                      </div>
                    )}

                    <div
                      className={`max-w-[100%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                        isVendor
                          ? "bg-zinc-900 text-zinc-50 rounded-br-sm ml-auto"
                          : "bg-white text-zinc-900 border border-zinc-200 rounded-bl-sm"
                      }`}
                    >
                      <p className="text-[11px] uppercase tracking-[0.18em] mb-1 opacity-70">
                        {isVendor ? "Vendor" : "AI Concierge"}
                      </p>
                      <p>{m.content}</p>
                    </div>
                  </div>
                </div>
              );
            })}

            {isSending && (
              <div className="flex justify-start mb-2">
                <div className="bg-white border border-zinc-200 rounded-2xl rounded-bl-sm px-4 py-3 text-xs text-zinc-500 flex items-center gap-2 shadow-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-400 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-400 animate-bounce delay-75" />
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-400 animate-bounce delay-150" />
                  <span className="ml-2">Preparing a response…</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Input */}
        <div className="px-6 pb-6 pt-2 border-t border-zinc-100 bg-white">
          <form onSubmit={handleSubmit} className="flex gap-3 items-center">
            <input
              className="flex-1 border border-zinc-200 rounded-full px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900/80 focus:border-zinc-900/80 placeholder:text-zinc-400"
              placeholder="Type your message here…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button
              type="submit"
              disabled={!input.trim() || isSending}
              className="rounded-full px-6 py-3 text-sm font-medium text-white bg-zinc-900 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-zinc-800 transition-colors"
            >
              {isSending ? "Sending…" : "Send"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
